<?php echo esc_attr($nonce); ?>
<label for="fs_seo_ilj_focus_keyphrase">
    <?php echo esc_html__('Enter Focus Keyphrase:', 'fs-seo-internal-link-juicer'); ?>
</label>
<br>
<input type="text" name="fs_seo_ilj_focus_keyphrase" id="fs_seo_ilj_focus_keyphrase" value="<?php echo esc_attr($value); ?>" />